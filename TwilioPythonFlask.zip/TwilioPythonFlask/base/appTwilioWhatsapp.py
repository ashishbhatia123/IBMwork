# Download the helper library from https://www.twilio.com/docs/python/install
import os
from twilio.rest import Client


# Find your Account SID and Auth Token at twilio.com/console
# and set the environment variables. See http://twil.io/secure
account_sid = 'AC1d2d2f911b5bf6524430f2ccfd24546e'
auth_token = '81b9b170c2de568f82e5ec2deae99bff'
client = Client(account_sid, auth_token)

message = client.messages.create(
                              body='Hello sushant   ',
                              from_='whatsapp:+14155238886',
                              to='whatsapp:+919458207565'
                          )

print(message.sid)
