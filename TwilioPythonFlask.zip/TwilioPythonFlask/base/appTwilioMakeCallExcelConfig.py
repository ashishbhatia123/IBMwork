import os
from twilio.rest import Client


from openpyxl import load_workbook

# Assuming your Excel file is named 'your_file.xlsx' and it's in the same directory as your Python script
file_path = 'C:/Users/000P3X744/Desktop/Twilio Neeraj Presentation/Twilio ConfigFile.xlsx'

# Load the workbook
wb = load_workbook(filename=file_path)

# Select the sheet named 'whatsapp'
sheet = wb['Voice']

# Access the value of cell
fromsss = sheet['E6'].value
to = sheet['E8'].value






# Find your Account SID and Auth Token at twilio.com/console
# and set the environment variables. See http://twil.io/secure
account_sid = 'AC1d2d2f911b5bf6524430f2ccfd24546e'
auth_token = '81b9b170c2de568f82e5ec2deae99bff'
client = Client(account_sid, auth_token)

call = client.calls.create(
                        url='http://demo.twilio.com/docs/voice.xml',
                        to= to,
                        from_=fromsss
                    )

print(call.sid)