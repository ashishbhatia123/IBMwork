import os
from twilio.rest import Client

# Find your Account SID and Auth Token at twilio.com/console
# and set the environment variables. See http://twil.io/secure
account_sid = 'AC1d2d2f911b5bf6524430f2ccfd24546e'
auth_token = '81b9b170c2de568f82e5ec2deae99bff'
client = Client(account_sid, auth_token)

call = client.calls.create(
                        url='http://demo.twilio.com/docs/voice.xml',
                        to= '+919458207565',
                        from_='+16188511892'
                    )

print(call.sid)