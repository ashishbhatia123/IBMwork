import plivo

client = plivo.RestClient('MAZGYWZDC4YZEWOTGZYT','MmFkYzAyMmM3MDU1MjhmYjBkY2Y4YTEwYTBlNWE4')
response = client.calls.create(
    from_='+19362792086',
    to_='+919458207565',
    answer_url='https://gda.s3.eu-de.cloud-object-storage.appdomain.cloud/Speak.xml',
    answer_method='GET', )
print(response)

# https://chebz162229094.sl2469408.sl.dst.ibm.com/en/speak.xml
# https://s3.amazonaws.com/static.plivo.com/answer.xml