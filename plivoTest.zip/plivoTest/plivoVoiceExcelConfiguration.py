import plivo


from openpyxl import load_workbook

# Assuming your Excel file is named 'your_file.xlsx' and it's in the same directory as your Python script
file_path = 'C:/Users/000P3X744/Desktop/plivoTest/Plivo ConfigFile.xlsx'

# Load the workbook
wb = load_workbook(filename=file_path)

# Select the sheet named 'whatsapp'
sheet = wb['Voice']

# Access the value of cell
fromss = sheet['E6'].value
to = sheet['E8'].value
URL = sheet['E10'].value












client = plivo.RestClient('MAYWJMZGFJODLKMDG4Y2','MjlmYzU0NTQ3YmU0NTAyY2M1OWRiNTg5YTY0MTUy')
response = client.calls.create(
    from_= fromss,
    to_= to,
    answer_url= URL,
    answer_method='GET', )
print(response)