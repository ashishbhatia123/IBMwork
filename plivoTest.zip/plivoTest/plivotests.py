import plivo

client = plivo.RestClient('MAYWJMZGFJODLKMDG4Y2','MjlmYzU0NTQ3YmU0NTAyY2M1OWRiNTg5YTY0MTUy')
response = client.calls.create(
    from_='+19362792086',
    to_='+919458207565',
    answer_url='https://7bbf-103-163-91-192.ngrok-free.app',
    answer_method='GET', )
print(response)